import Product from "../models/Product.js";
import { scrapeProduct } from "../scraper/scrapeProduct.js";

export async function addProduct(req, res) {
  try {
    const { url } = req.body;

    // DEBUG — VERY IMPORTANT
    console.log("URL RECEIVED FROM FRONTEND:", url);

    // CLEAN URL (remove tracking junk)
    const cleanUrl = url.split("?")[0];
    console.log("CLEAN URL:", cleanUrl);

    const data = await scrapeProduct(cleanUrl);

   const newProduct = await Product.create({
  url: cleanUrl,
  name: data.name,
  price: data.price,
  image: data.image  // <-- add this
});


    res.json(newProduct);
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Scraping failed" });
  }
}

export async function getProducts(req, res) {
  try {
    const products = await Product.find().sort({ _id: -1 });
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: "Cannot fetch products" });
  }
}
