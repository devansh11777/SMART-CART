import mongoose from "mongoose";

const productSchema = new mongoose.Schema({
  url: String,
  name: String,
  price: Number,
  image: String  // <-- add this
});

export default mongoose.model("Product", productSchema);
