import express from "express";
import { addProduct, getProducts } from "../controllers/productController.js";
import Product from "../models/Product.js";  // ✅ FIX: Add this

const router = express.Router();

router.post("/add", addProduct);
router.get("/", getProducts);

router.delete("/delete/:id", async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ message: "Deleted" });
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "Delete failed" });
  }
});

export default router;