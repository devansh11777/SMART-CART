import axios from "axios";
import * as cheerio from "cheerio";

export async function scrapeProduct(url) {
  try {
    const { data } = await axios.get(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64 reminding Gecko) Chrome/120 Safari/537.36",
        "Accept-Language": "en-IN,en;q=0.9"
      }
    });

    const $ = cheerio.load(data);

    // ✅ Product name
    const name = $("#productTitle").text().trim();

    // ✅ PRICE — robust selector
    let priceText =
      $(".a-price .a-offscreen").first().text().trim() ||   // most reliable
      $("#priceblock_ourprice").text().trim() ||
      $("#priceblock_dealprice").text().trim();

    if (!priceText) {
      throw new Error("Price not found");
    }

    const price = Number(priceText.replace(/[₹,]/g, ""));

    // ✅ Product image
    const image =
      $("#landingImage").attr("src") ||
      $("#imgTagWrapperId img").attr("src") ||
      $("img[data-old-hires]").attr("data-old-hires");

    return { name, price, image };

  } catch (error) {
    console.error("SCRAPE ERROR:", error.message);
    return { name: "Unknown Product", price: 0, image: "" };
  }
}
