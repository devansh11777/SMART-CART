import { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";

function App() {
  const [url, setUrl] = useState("");
  const [products, setProducts] = useState([]);
  const [budget, setBudget] = useState("");
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState("light");

  const loadProducts = async () => {
    setLoading(true);
    const res = await axios.get("http://localhost:5001/api/products");
    setProducts(res.data);
    setLoading(false);
  };

  const addProduct = async () => {
    if (!url.trim()) return alert("Please paste a product link");
    await axios.post("http://localhost:5001/api/products/add", { url });
    setUrl("");
    loadProducts();
  };

  const deleteProduct = async (id) => {
    await axios.delete(`http://localhost:5001/api/products/delete/${id}`);
    loadProducts();
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const total = products.reduce((s, p) => s + p.price, 0);
  const remaining = budget ? budget - total : null;

  return (
    <div className={`app ${theme}`}>
      {/* HEADER */}
      <header className="header">
        <div className="brand">
          🛒 <span>SmartCart</span>
        </div>

        <div className="header-actions">
          <button
            className="theme-toggle"
            onClick={() =>
              setTheme(theme === "light" ? "dark" : "light")
            }
          >
            {theme === "light" ? "🌙 Dark" : "☀️ Light"}
          </button>

          <div className="user-chip">
            <div className="avatar">U</div>
            <div className="user-text">
              <strong>User</strong>
              <span>Personal Cart</span>
            </div>
          </div>
        </div>
      </header>

      {/* MAIN */}
      <main className="container">
        {/* INPUT CARD */}
        <section className="card">
          <h3>Add Product</h3>

          <label>Product Link</label>
          <div className="input-group">
            <input
              placeholder="https://example.com/product"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
            />
            <button onClick={addProduct}>Add</button>
          </div>

          <label>Monthly Budget (₹)</label>
          <input
            type="number"
            placeholder="Enter your budget"
            value={budget}
            onChange={(e) => setBudget(Number(e.target.value))}
          />
        </section>

        {/* SUMMARY */}
        <section className="summary">
          <div className="summary-box">
            <span>Total</span>
            <strong>₹{total}</strong>
          </div>

          {budget > 0 && (
            <div
              className={`summary-box ${
                remaining < 0 ? "danger" : "success"
              }`}
            >
              <span>
                {remaining < 0 ? "Over Budget" : "Remaining"}
              </span>
              <strong>
                ₹{Math.abs(remaining)}
              </strong>
            </div>
          )}
        </section>

        {/* PRODUCTS */}
        <section>
          <h3>Your Products</h3>

          {loading
            ? Array(3)
                .fill(0)
                .map((_, i) => (
                  <div className="skeleton" key={i}></div>
                ))
            : products.map((p) => (
                <div className="product-card" key={p._id}>
                  <img src={p.image} alt="product" />
                  <div className="product-info">
                    <strong>{p.name}</strong>
                    <span>₹{p.price}</span>
                  </div>
                  <button
                    className="delete-btn"
                    onClick={() => deleteProduct(p._id)}
                  >
                    ✕
                  </button>
                </div>
              ))}
        </section>
      </main>
    </div>
  );
}

export default App;
