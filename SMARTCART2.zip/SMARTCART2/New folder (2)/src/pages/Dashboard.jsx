import { useState, useEffect } from "react";
import axios from "axios";
import "../styles/dashboard.css";

function Dashboard() {
    const [url, setUrl] = useState("");
    const [products, setProducts] = useState([]);
    const [budget, setBudget] = useState("");
    const [loading, setLoading] = useState(true);
    const [theme, setTheme] = useState("light");

    // Use the Vite backend port (usually 5000 based on server.js)
    const API_URL = "http://localhost:5000/api/products";

    const loadProducts = async () => {
        setLoading(true);
        try {
            const res = await axios.get(API_URL);
            setProducts(res.data);
        } catch (err) {
            console.error("Failed to load products", err);
        }
        setLoading(false);
    };

    const playBeep = () => {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = "sine";
        osc.frequency.value = 1200; // High pitch beep
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.00001, ctx.currentTime + 0.2);
        osc.start();
        osc.stop(ctx.currentTime + 0.2);
    };

    const addProduct = async () => {
        if (!url.trim()) return alert("Please paste a product link");
        try {
            await axios.post(`${API_URL}/add`, { url });
            playBeep(); // 🔊 BEEP!
            setUrl("");
            loadProducts();
        } catch (err) {
            alert("Failed to add product");
        }
    };

    const deleteProduct = async (id) => {
        try {
            await axios.delete(`${API_URL}/delete/${id}`);
            loadProducts();
        } catch (err) {
            alert("Failed to delete product");
        }
    };

    useEffect(() => {
        loadProducts();
    }, []);

    const playAlert = () => {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = "sawtooth"; // Harsher sound for warning
        osc.frequency.value = 200; // Low pitch
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.4);
        osc.start();
        osc.stop(ctx.currentTime + 0.4);
    };

    // Watch for Budget Overflow
    useEffect(() => {
        const currentTotal = products.reduce((s, p) => s + p.price, 0);
        let interval;

        if (budget > 0 && currentTotal > budget) {
            playAlert(); // Play immediate
            interval = setInterval(playAlert, 1000); // 🔁 Repeat every 1 second
        }

        return () => {
            if (interval) clearInterval(interval);
        };
    }, [products, budget]);

    const total = products.reduce((s, p) => s + p.price, 0);
    const remaining = budget ? budget - total : null;

    return (
        <div className={`dashboard-container ${theme}`}>
            {/* HEADER */}
            <header className="dashboard-header">
                <div className="brand">
                    🛒 <span>SmartCart</span>
                </div>

                <div className="header-actions">
                    <button
                        className="theme-toggle"
                        onClick={() => setTheme(theme === "light" ? "dark" : "light")}
                    >
                        {theme === "light" ? "🌙 Dark" : "☀️ Light"}
                    </button>

                    <div className="user-chip">
                        <div className="avatar">U</div>
                        <div className="user-text">
                            <strong>User</strong>
                            <span>Personal Cart</span>
                        </div>
                    </div>
                </div>
            </header>

            {/* MAIN */}
            <main className="dashboard-main">
                {/* INPUT CARD */}
                <section className="dashboard-card">
                    <h3>Add Product</h3>

                    <label>Product Link</label>
                    <div className="input-group">
                        <input
                            placeholder="https://example.com/product"
                            value={url}
                            onChange={(e) => setUrl(e.target.value)}
                        />
                        <button onClick={addProduct}>Add</button>
                    </div>

                    <label>Monthly Budget (₹)</label>
                    <input
                        type="number"
                        placeholder="Enter your budget"
                        value={budget}
                        onChange={(e) => setBudget(Number(e.target.value))}
                    />
                </section>

                {/* SUMMARY */}
                <section className="summary">
                    <div className="summary-box">
                        <span>Total</span>
                        <strong>₹{total}</strong>
                    </div>

                    {budget > 0 && (
                        <div
                            className={`summary-box ${remaining < 0 ? "danger" : "success"}`}
                        >
                            <span>{remaining < 0 ? "Over Budget" : "Remaining"}</span>
                            <strong>₹{Math.abs(remaining)}</strong>
                        </div>
                    )}
                </section>

                {/* PRODUCTS */}
                <section>
                    <h3>Your Products</h3>

                    {loading ? (
                        Array(3)
                            .fill(0)
                            .map((_, i) => <div className="skeleton" key={i}></div>)
                    ) : (
                        products.map((p) => (
                            <div className="product-card" key={p._id}>
                                <img src={p.image} alt="product" />
                                <div className="product-info">
                                    <strong>{p.name}</strong>
                                    <span>₹{p.price}</span>
                                </div>
                                <button
                                    className="delete-btn"
                                    onClick={() => deleteProduct(p._id)}
                                >
                                    ✕
                                </button>
                            </div>
                        ))
                    )}
                </section>
            </main>
        </div>
    );
}

export default Dashboard;
