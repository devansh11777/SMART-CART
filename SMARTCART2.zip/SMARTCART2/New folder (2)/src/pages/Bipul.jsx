import { useEffect } from "react";

export default function Bipul() {
  useEffect(() => {
    // Redirect to your cart app
    window.location.href = "http://localhost:3000";
  }, []);

  return (
    <h1 className="text-center text-4xl font-bold mt-10">
      Redirecting to Smart Cart...
    </h1>
  );
}
