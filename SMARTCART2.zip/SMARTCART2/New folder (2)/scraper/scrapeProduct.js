const puppeteer = require("puppeteer");

async function scrapeProduct(url) {
  let browser;
  try {
    browser = await puppeteer.launch({
      headless: "new",
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });
    const page = await browser.newPage();

    // Set a real user agent
    await page.setUserAgent(
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    );

    // Go to URL
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 30000 });

    // Scrape data using in-page DOM
    const data = await page.evaluate(() => {
      const name = document.getElementById("productTitle")?.innerText.trim();

      const priceElement =
        document.querySelector(".a-price .a-offscreen") ||
        document.getElementById("priceblock_ourprice") ||
        document.getElementById("priceblock_dealprice");

      const priceText = priceElement?.innerText.trim();
      const price = priceText ? Number(priceText.replace(/[₹,]/g, "")) : 0;

      const imageElement =
        document.getElementById("landingImage") ||
        document.querySelector("#imgTagWrapperId img");

      const image = imageElement?.src || imageElement?.getAttribute("data-old-hires");

      return { name, price, image };
    });

    if (!data.name) throw new Error("Product name not found");
    if (!data.price) throw new Error("Price not found");

    await browser.close();
    return data;

  } catch (error) {
    console.error("PUPPETEER ERROR:", error.message);
    if (browser) await browser.close();
    return { name: "Unknown Product", price: 0, image: "" };
  }
}

module.exports = { scrapeProduct };
