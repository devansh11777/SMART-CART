const Product = require("../models/Product");
const { scrapeProduct } = require("../scraper/scrapeProduct");

exports.addProduct = async (req, res) => {
    try {
        const { url } = req.body;

        console.log("URL RECEIVED:", url);

        // Clean URL
        const cleanUrl = url.split("?")[0];

        const data = await scrapeProduct(cleanUrl);

        const newProduct = await Product.create({
            url: cleanUrl,
            name: data.name,
            price: data.price,
            image: data.image,
        });

        res.json(newProduct);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Scraping failed" });
    }
};

exports.getProducts = async (req, res) => {
    try {
        const products = await Product.find().sort({ _id: -1 });
        res.json(products);
    } catch (error) {
        res.status(500).json({ error: "Cannot fetch products" });
    }
};

exports.deleteProduct = async (req, res) => {
    try {
        await Product.findByIdAndDelete(req.params.id);
        res.json({ message: "Deleted" });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Delete failed" });
    }
};
